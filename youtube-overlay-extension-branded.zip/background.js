// background.js - minimal
chrome.runtime.onInstalled.addListener(() => { console.log('YT Overlay (branded) installed'); });