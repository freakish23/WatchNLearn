// content.js - loads activities.json and injects overlay, triggers checkpoints (branded)
(async function () {
  const activitiesUrl = chrome.runtime.getURL('activities.json');
  let activitiesMap = {};
  try {
    const resp = await fetch(activitiesUrl);
    activitiesMap = await resp.json();
  } catch (e) {
    console.error('[YT-Overlay] failed to load activities.json', e);
    return;
  }

  function getVideoId() {
    const url = new URL(window.location.href);
    return url.searchParams.get('v');
  }

  const videoId = getVideoId();
  if (!videoId) return;

  const videoBundle = activitiesMap[videoId];
  if (!videoBundle || !Array.isArray(videoBundle.activities) || videoBundle.activities.length === 0) {
    console.log('[YT-Overlay] No activities for', videoId);
    return;
  }

  // map activities to checkpoint shape
  const checkpoints = videoBundle.activities.map(act => {
    const answerIndex = (act.type === 'quiz' && Array.isArray(act.options))
      ? act.options.findIndex(o => o.correct === true)
      : null;
    return {
      checkpoint_id: act.id || `${videoId}_${act.timestamp}`,
      video_id: videoId,
      trigger_time_s: Number(act.timestamp || 0),
      type: act.type,
      prompt: act.title || act.prompt || act.question || '',
      options: act.options ? act.options.map(o => o.text).join('|') : '',
      answer_index: answerIndex,
      explanation: act.explanation || '',
      widget_props: JSON.stringify(act),
      pause: "yes",
      resume: (["quiz"].includes(act.type)) ? "auto" : "button",
      tag: act.id || act.type
    };
  }).map(c => ({ ...c, triggered: false }));

  // inject iframe overlay
  function injectOverlay() {
    if (document.getElementById('yt-learning-iframe')) return document.getElementById('yt-learning-iframe');
    const iframe = document.createElement('iframe');
    iframe.id = 'yt-learning-iframe';
    iframe.src = chrome.runtime.getURL('overlay.html');
    Object.assign(iframe.style, {
      position: 'fixed',
      right: '22px',
      bottom: '22px',
      width: '460px',
      height: '420px',
      zIndex: 2147483647,
      border: '0',
      boxShadow: '0 12px 36px rgba(0,0,0,0.25)',
      borderRadius: '14px',
      overflow: 'hidden',
      backgroundColor: 'white'
    });
    iframe.style.pointerEvents = 'auto';
    document.body.appendChild(iframe);
    iframe.addEventListener('load', () => {
      try { iframe.contentWindow.postMessage({ type: 'overlay_loaded', videoMeta: videoBundle }, '*'); } catch(e){}
    });
    return iframe;
  }

  const iframe = injectOverlay();

  // wait for video element
  function waitForVideo() {
    return new Promise(resolve => {
      const t0 = Date.now();
      (function check() {
        const v = document.querySelector('video');
        if (v) return resolve(v);
        if (Date.now() - t0 > 15000) return resolve(null);
        requestAnimationFrame(check);
      })();
    });
  }

  const video = await waitForVideo();
  if (!video) return;

  function postToIframe(msg) {
    if (!iframe || !iframe.contentWindow) return;
    iframe.contentWindow.postMessage(msg, '*');
  }

  postToIframe({ type: 'init', videoId, checkpoints });

  const tolerance = 1.2;
  console.log('[YT-Overlay] videoId=', videoId, 'checkpoints=', checkpoints.length);

  setInterval(() => {
    if (!video || video.readyState === 0) return;
    const now = video.currentTime;
    if (Math.floor(now) % 5 === 0) {
      console.debug('[YT-Overlay] currentTime', now.toFixed(2));
    }
    checkpoints.forEach(cp => {
      if (cp.triggered) return;
      const diff = Math.abs(cp.trigger_time_s - now);
      if (diff <= tolerance) {
        cp.triggered = true;
        console.log(`[YT-Overlay] Triggering checkpoint @${cp.trigger_time_s}s`, cp);
        if (cp.pause && String(cp.pause).toLowerCase() === 'yes') {
          try { video.pause(); } catch(e){ console.warn('pause failed', e); }
        }
        postToIframe({ type: 'show_checkpoint', checkpoint: cp });
      }
    });
  }, 400);

  window.addEventListener('message', e => {
    const data = e.data || {};
    if (!data.type) return;
    if (data.type === 'resume_video') {
      video.play().catch(() => {});
    }
    if (data.type === 'save_progress') {
      const key = `ytprog_${videoId}`;
      chrome.storage.local.get([key], r => {
        const cur = r[key] || {};
        cur[data.checkpointId] = data.value;
        chrome.storage.local.set({ [key]: cur });
      });
    }
    if (data.type === 'request_progress') {
      const key = `ytprog_${videoId}`;
      chrome.storage.local.get([key], r => {
        postToIframe({ type: 'progress_data', data: r[key] || {} });
      });
    }
  });
})();