// overlay-ui.js - branded version with tags & insights
console.log('[Overlay UI] branded script loaded');
document.addEventListener('DOMContentLoaded', ()=>{ try{ document.body.style.backgroundColor='#fff'; document.body.style.minHeight='100%'; }catch(e){} });

const content = document.getElementById('content');
const progressText = document.getElementById('progressText');
const minimizeBtn = document.getElementById('minimizeBtn');
const videoThumb = document.getElementById('videoThumb');
const videoTitle = document.getElementById('videoTitle');
const videoAuthor = document.getElementById('videoAuthor');
const videoTags = document.getElementById('videoTags');
const insightChips = document.getElementById('insightChips');

let videoId = null;

minimizeBtn.addEventListener('click', ()=>{ content.style.display = content.style.display === 'none' ? 'block' : 'none'; });

function escapeHtml(s){ if(!s) return ''; return String(s).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;'); }
function parseActivity(cp){ try{ return JSON.parse(cp.widget_props||'{}'); }catch(e){ return {}; } }

function setHeaderMeta(meta){
  if(!meta) return;
  videoThumb.src = meta.thumbnail || '';
  videoTitle.innerText = meta.title || meta.video_title || '';
  videoAuthor.innerText = meta.author || '';
  // tags — create sample chips from title keywords if none provided
  videoTags.innerHTML = '';
  const tags = (meta.tags && Array.isArray(meta.tags)) ? meta.tags : (meta.title ? meta.title.split(' ').slice(0,3) : []);
  tags.forEach(t=>{ const el = document.createElement('div'); el.className='tag'; el.innerText = t; videoTags.appendChild(el); });
  // insight chips — clear by default
  insightChips.innerHTML = '';
  const defaultChips = ['Quick check','Active recall','Micro-exercise'];
  defaultChips.forEach(c=>{ const chip = document.createElement('div'); chip.className='chip'; chip.innerHTML = `<span class="dot"></span>${escapeHtml(c)}`; insightChips.appendChild(chip); });
}

// renderers (quiz, slider, budget, reflection) - reuse previous implementations but add insight tags
function renderQuiz(cp){
  const act = parseActivity(cp);
  const opts = (act.options||[]).map(o=>o.text);
  const answerIndex = (act.options||[]).findIndex(o=>o.correct===true);
  const wrapper = document.createElement('div');
  wrapper.innerHTML = `<div><div class="prompt">${escapeHtml(cp.prompt||act.title||act.question)}</div><form id="quizForm" class="quiz-form">${opts.map((o,i)=>`<label class="quiz-option"><input type="radio" name="opt" value="${i}"><span class="opt-text">${escapeHtml(o)}</span></label>`).join('')}</form><div id="quizFeedback" class="feedback"></div><div class="actions"><button id="submitBtn" class="primary">Submit</button><button id="skipBtn" class="secondary">Skip</button></div></div>`;
  content.innerHTML=''; content.appendChild(wrapper);
  // show insight chip for this question
  addInsight(`Question: ${act.title||cp.prompt}`);
  document.getElementById('submitBtn').addEventListener('click',(ev)=>{ ev.preventDefault(); const form=document.getElementById('quizForm'); const val=new FormData(form).get('opt'); const fb=document.getElementById('quizFeedback'); if(val===null){ fb.innerText='Select an option to continue.'; fb.style.color='#b91c1c'; return; } const picked=Number(val); const correct=picked===answerIndex; fb.innerText = correct?`✅ Correct — ${act.explanation||cp.explanation||''}`:`❌ Not quite — ${act.explanation||cp.explanation||''}`; fb.style.color = correct? '#15803d':'#b91c1c'; window.parent.postMessage({ type:'save_progress', checkpointId:`${videoId}_${cp.trigger_time_s}`, value:{ outcome: correct?'correct':'incorrect', picked, time:Date.now() } }, '*'); if(cp.resume==='auto') setTimeout(()=>window.parent.postMessage({ type:'resume_video', resume:'auto' }, '*'),600); else { const cont=document.createElement('button'); cont.className='primary'; cont.style.marginTop='8px'; cont.innerText='Continue'; cont.addEventListener('click',()=>window.parent.postMessage({ type:'resume_video', resume:'button' }, '*')); wrapper.appendChild(cont); } });
  document.getElementById('skipBtn').addEventListener('click',()=>{ window.parent.postMessage({ type:'skip_checkpoint' }, '*'); window.parent.postMessage({ type:'resume_video', resume:'button' }, '*'); });
}

function renderSlider(cp){
  const act = parseActivity(cp); const min = act.min??0, max=act.max??10, step=act.step??1, def=act.default??min;
  const wrapper=document.createElement('div'); wrapper.innerHTML=`<div><div class="prompt">${escapeHtml(act.title||cp.prompt)}</div><div class="slider-area"><input id="theRange" type="range" min="${min}" max="${max}" step="${step}" value="${def}"><div class="range-row"><div class="range-value">Value: <span id="rangeVal">${def}</span></div><div id="sliderObservation" class="observation">${escapeHtml(act.explanation||cp.explanation||'')}</div></div></div><div class="actions"><button id="contBtn" class="primary">Continue</button><button id="skipBtn" class="secondary">Skip</button></div></div>`;
  content.innerHTML=''; content.appendChild(wrapper); const range=wrapper.querySelector('#theRange'); const val=wrapper.querySelector('#rangeVal'); const obs=wrapper.querySelector('#sliderObservation');
  addInsight(`Slider: ${act.title||cp.prompt}`);
  range.addEventListener('input', e=>{ val.innerText=e.target.value; obs.innerText = (act.feedback? (function(v){ for(let f of act.feedback||[]){ if(v>=f.range[0] && v<=f.range[1]) return f.message;} return act.explanation||'Changed value.';})(Number(e.target.value)) : (act.explanation||cp.explanation||'Try observing the change.')); });
  wrapper.querySelector('#contBtn').addEventListener('click', ()=>{ const value=range.value; window.parent.postMessage({ type:'save_progress', checkpointId:`${videoId}_${cp.trigger_time_s}`, value:{ outcome:'slider_done', value, time:Date.now() } }, '*'); window.parent.postMessage({ type:'resume_video', resume:cp.resume||'button' }, '*'); });
  wrapper.querySelector('#skipBtn').addEventListener('click', ()=>{ window.parent.postMessage({ type:'skip_checkpoint' }, '*'); window.parent.postMessage({ type:'resume_video', resume:'button' }, '*'); });
}

function renderBudget(cp){
  const act=parseActivity(cp); const total=act.total||1000; const categories=act.categories||[];
  const wrapper=document.createElement('div'); wrapper.innerHTML=`<div><div class="prompt">${escapeHtml(act.title||act.prompt||cp.prompt)}</div><div class="muted small" style="margin-bottom:8px">${escapeHtml(act.prompt||'')}</div><div id="budgetArea"></div><div id="budgetFeedback" class="feedback" style="margin-top:8px"></div><div class="actions" style="margin-top:10px"><button id="budgetSave" class="primary">Submit</button><button id="budgetSkip" class="secondary">Skip</button></div></div>`;
  content.innerHTML=''; content.appendChild(wrapper); const budgetArea=wrapper.querySelector('#budgetArea');
  categories.forEach(cat=>{ const row=document.createElement('div'); row.className='budget-row'; row.innerHTML=`<div style="flex:1">${escapeHtml(cat.label)}</div><div style="display:flex;align-items:center;gap:8px"><input class="budget-input" type="number" min="${cat.min||0}" max="${cat.max||total}" value="${cat.min||0}" data-cat="${cat.id}"><div class="small">min ${cat.min} - max ${cat.max}</div></div>`; budgetArea.appendChild(row); });
  function getAllocations(){ const inputs=budgetArea.querySelectorAll('input[type="number"]'); const allocs={}; inputs.forEach(inp=>allocs[inp.dataset.cat]=Number(inp.value||0)); return allocs; }
  addInsight(`Budget: ${act.title||cp.prompt}`);
  wrapper.querySelector('#budgetSave').addEventListener('click', ()=>{ const allocs=getAllocations(); const allocatedTotal=Object.values(allocs).reduce((s,v)=>s+v,0); const feedbackDiv=wrapper.querySelector('#budgetFeedback'); if(allocatedTotal!==total){ feedbackDiv.innerText=`Please allocate exactly ${total}. You have allocated ${allocatedTotal}.`; feedbackDiv.style.color='#b91c1c'; return; } const primaryId = categories[0] && categories[0].id; const primaryValue = allocs[primaryId]||0; const primaryPct = (primaryValue/total)*100; const rules = act.feedback_rules||[]; let matched=null; for(let r of rules){ if(primaryPct>=r.min_pct && primaryPct<r.max_pct){ matched = r.message; break; } } const message = matched || 'Allocation saved.'; feedbackDiv.innerText = message; feedbackDiv.style.color = '#15803d'; window.parent.postMessage({ type:'save_progress', checkpointId:`${videoId}_${cp.trigger_time_s}`, value:{ outcome:'budget_saved', allocations:allocs, time:Date.now() } }, '*'); window.parent.postMessage({ type:'resume_video', resume:cp.resume||'button' }, '*'); });
  wrapper.querySelector('#budgetSkip').addEventListener('click', ()=>{ window.parent.postMessage({ type:'skip_checkpoint' }, '*'); window.parent.postMessage({ type:'resume_video', resume:'button' }, '*'); });
}

function renderReflection(cp){ const act=parseActivity(cp); const wrapper=document.createElement('div'); wrapper.innerHTML=`<div><div class="prompt">${escapeHtml(act.title||cp.prompt)}</div><div class="muted small" style="margin-bottom:8px">${escapeHtml(act.hint||'')}</div><textarea id="reflectionText" placeholder="Type your thoughts here..." style="width:100%;height:110px;padding:8px;border-radius:8px;border:1px solid #e5e7eb;"></textarea><div style="margin-top:8px" id="reflectionFeedback"></div><div class="actions" style="margin-top:10px"><button id="reflectionSave" class="primary">Save</button><button id="reflectionSkip" class="secondary">Skip</button></div></div>`; content.innerHTML=''; content.appendChild(wrapper); addInsight(`Reflect: ${act.title||cp.prompt}`); wrapper.querySelector('#reflectionSave').addEventListener('click', ()=>{ const txt=wrapper.querySelector('#reflectionText').value.trim(); if(!txt){ const fb=wrapper.querySelector('#reflectionFeedback'); fb.innerText='Please enter a short reflection before saving.'; fb.style.color='#b91c1c'; return; } window.parent.postMessage({ type:'save_progress', checkpointId:`${videoId}_${cp.trigger_time_s}`, value:{ outcome:'reflection', text:txt, time:Date.now() } }, '*'); wrapper.querySelector('#reflectionFeedback').innerText='Saved — thanks for reflecting!'; wrapper.querySelector('#reflectionFeedback').style.color='#15803d'; window.parent.postMessage({ type:'resume_video', resume:cp.resume||'button' }, '*'); }); wrapper.querySelector('#reflectionSkip').addEventListener('click', ()=>{ window.parent.postMessage({ type:'skip_checkpoint' }, '*'); window.parent.postMessage({ type:'resume_video', resume:'button' }, '*'); }); }

function addInsight(text){ try{ const chip=document.createElement('div'); chip.className='chip'; chip.innerHTML=`<span class="dot"></span>${escapeHtml(text)}`; insightChips.appendChild(chip); }catch(e){} }

window.addEventListener('message', e=>{ console.debug('[Overlay UI] got message', e.data); const data=e.data||{}; if(!data.type) return; if(data.type==='init'){ videoId=data.videoId; const count=(data.checkpoints&&data.checkpoints.length)||0; progressText.innerText=`${count} checkpoints loaded`; return; } if(data.type==='overlay_loaded'){ setHeaderMeta(data.videoMeta||{}); return; } if(data.type==='show_checkpoint'){ const cp=data.checkpoint; if(!cp) return; insightChips.innerHTML=''; if(cp.type==='quiz') renderQuiz(cp); else if(cp.type==='slider') renderSlider(cp); else if(cp.type==='drag') renderDrag(cp); else if(cp.type==='budget') renderBudget(cp); else if(cp.type==='reflection') renderReflection(cp); else { console.warn('[Overlay UI] Unsupported checkpoint type', cp.type); content.innerHTML=`<div class="overlay-muted">Unsupported type: ${escapeHtml(cp.type)}</div>`; } return; } }, false);